from __future__ import absolute_import

from .bcftools import MultiqcModule
